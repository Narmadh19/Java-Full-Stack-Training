package com.example.Front_Back_End;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
