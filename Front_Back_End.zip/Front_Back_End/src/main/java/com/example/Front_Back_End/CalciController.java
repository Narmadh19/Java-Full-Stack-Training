package com.example.Front_Back_End;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;

@RestController
@RequestMapping("/calc")
public class CalciController {
    @GetMapping("/add/{a}/{b}")
    public double add(@PathVariable double a, @PathVariable double b) {
        return a+b;
    }

    @GetMapping("/sub/{a}/{b}")
    public double  sub(@PathVariable double a, @PathVariable double b) {
        return a-b;
    }

    @GetMapping("/mul/{a}/{b}")
    public double mul(@PathVariable double a, @PathVariable double b) {
        return a*b;
    }

    @GetMapping("/div/{a}/{b}")
    public double div(@PathVariable double a, @PathVariable double b) {
        return a/b;
    }

    @GetMapping("/sqrt/{n}")
    public double sqrt(@PathVariable double n) {
        return Math.sqrt(n);
    }

    @GetMapping("/power/{a}/{b}")
    public double power(@PathVariable double a, @PathVariable double b) {
        return Math.pow(a, b);
    }

    @GetMapping("/sin/{n}")
    public double sin(@PathVariable double n) {
        return Math.sin(Math.toRadians(n));
    }

    @GetMapping("/cos/{n}")
    public double cos(@PathVariable double n) {
        return Math.cos(Math.toRadians(n));
    }

    @GetMapping("/tan/{n}")
    public double tan(@PathVariable double n) {
        return Math.tan(Math.toRadians(n));
    }

    @GetMapping("/log/{n}")
    public double log(@PathVariable double n) {
        return Math.log10(n);
    }

    @GetMapping("/ln/{n}")
    public double ln(@PathVariable double n) {
        return Math.log(n);
    }

    @GetMapping("/factorial/{n}")
    public long factorial(@PathVariable int n) {
        long fact = 1;

        for (int i = 1; i <= n; i++) {
            fact *= i;
        }

        return fact;
    }

    @GetMapping("/percentage/{total}/{percent}")
    public double percentage(
            @PathVariable double total,
            @PathVariable double percent) {

        return total - (total * percent / 100);
    }

    @GetMapping("/spiral")
    public String spiral() {

        int[][] mat = {
                {1,2,3},
                {4,5,6},
                {7,8,9}
        };

        int sr = 0;
        int startCol = 0;
        int er = mat.length - 1;
        int ec = mat[0].length - 1;

        List<Integer> res = new ArrayList<>();

        while (sr <= er && startCol <= ec) {

            // top
            for (int j = startCol; j <= ec; j++) {
                res.add(mat[sr][j]);
            }

            // right
            for (int i = sr + 1; i <= er; i++) {
                res.add(mat[i][ec]);
            }

            // bottom
            if (sr < er) {
                for (int j = ec - 1; j >= startCol; j--) {
                    res.add(mat[er][j]);
                }
            }

            // left
            if (startCol < ec) {
                for (int i = er - 1; i >= sr + 1; i--) {
                    res.add(mat[i][startCol]);
                }
            }

            sr++;
            er--;
            startCol++;
            ec--;
        }

        return res.toString();
    }
}
