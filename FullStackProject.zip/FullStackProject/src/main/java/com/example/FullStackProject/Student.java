package com.example.FullStackProject;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data //lombok generates getters/setters ,toString , equals, hashCode
@Table(name="Students")
public class Student {
    @Column(name="student_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "student_name",nullable = false,length=5)
    private String name;
    private String department;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="profile_id",referencedColumnName = "id")
    private Profile profile;

}
