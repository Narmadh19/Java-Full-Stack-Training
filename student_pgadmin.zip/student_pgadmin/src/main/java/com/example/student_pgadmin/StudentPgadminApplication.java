package com.example.student_pgadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentPgadminApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentPgadminApplication.class, args);
	}

}
