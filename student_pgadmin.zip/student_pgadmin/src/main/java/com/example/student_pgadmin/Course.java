package com.example.student_pgadmin;

import jakarta.persistence.*;

@Entity
@Table(name="Course")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int courseId;
    private String courseName;

    @ManyToOne
    @JoinColumn(name="id")
    private Student student;

    public Course(){}
    public Course(String courseName){
        this.courseName=courseName;
    }

    public String getCourseName(){
        return courseName;
    }

    public int getCourseId(){
        return courseId;
    }

    public void setCourseName(String courseName){
        this.courseName=courseName;
    }

}
