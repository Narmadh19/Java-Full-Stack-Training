package com.example.student_pgadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentPgadminApplicationTests {

	@Test
	void contextLoads() {
	}

}
