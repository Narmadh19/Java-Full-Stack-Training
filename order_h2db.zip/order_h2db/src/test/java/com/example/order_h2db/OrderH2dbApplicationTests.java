package com.example.order_h2db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderH2dbApplicationTests {

	@Test
	void contextLoads() {
	}

}
