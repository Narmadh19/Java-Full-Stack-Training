package com.example.order_h2db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderH2dbApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderH2dbApplication.class, args);
	}

}
