package com.example.Hero;
//MODEL CLASS
public class Hero {
    private String name;
    private String power;

    //Getters and Setters
    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name=name;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }
}
