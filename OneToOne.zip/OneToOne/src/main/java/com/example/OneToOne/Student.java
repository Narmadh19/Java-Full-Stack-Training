package com.example.OneToOne;

import jakarta.persistence.*;

@Entity
public class Student {
    @Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
    private String name;
    @JoinColumn(name = "profile_id")   // FK in student table
    private StudentProfile profile;

}
