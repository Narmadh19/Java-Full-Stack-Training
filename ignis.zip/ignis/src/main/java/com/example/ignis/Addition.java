package com.example.ignis;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Addition {

    @GetMapping("add/{num1}/{num2}")
    public String add(@PathVariable int num1, @PathVariable int num2) {
        int res=num1+num2;
        return (res%2==0)?"even":"odd";
    }

    @GetMapping("name/{name}")
    public String name(@PathVariable String name) {
        return (name.equals("clara"))?"Hii"+name:"No, It's not my name ";
    }

    @GetMapping("climate/{temp}")
    public String temp(@PathVariable int temp) {
        if(temp < 0){
            return "Shivering";
        }else if(temp>=0 && temp<=15){
            return "Chill";
        }else if(temp>15 && temp<=24){
            return "Happy";
        }else if(temp >24 && temp <=30){
            return "Towards Hot";
        }else if(temp>30 && temp <=32){
            return "HOTTER";
        }else{
            return"OMG";
        }
    }

    @GetMapping("/intro/{name}/{city}/{course}")
    public String intro(@PathVariable String name ,@PathVariable String city,@PathVariable String course){
        return "Hello, I am "+ name + " from"+ city +".Welcome to"+ course;
    }

    @GetMapping("/calc/{a}/{b}")
    public String calc(@PathVariable int a , @PathVariable int b){
        StringBuilder sb=new StringBuilder();
        sb.append("add:").append(a+b).append("\n");
        sb.append("sub:").append(a-b).append("\n");
        sb.append("mul:").append(a*b).append("\n");
        if(b!=0){
            sb.append("quo:").append(a/b).append("\n");
            sb.append("rem:").append(a%b).append("\n");
        }else{
            sb.append("quo Division by zero not allowed");
            sb.append("rem Division by zero not allowed");
        }
        return "<pre>" + sb.toString() +"</pre>";
    }
}


