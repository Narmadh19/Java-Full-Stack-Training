package com.example.ignis;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Cont {

        @GetMapping("/hello")
        public String hi(){
            return "<h1 style='color:violet;text-align : center'> Good afternoon!</h1> "+ "<h2 >This is IGNIS</h2>" +
                    "<img src='/img1.jpg' alt='Image'>" +
                    "<img src='https://www.giffywalls.in/products/starlit-rainbow-unicorn-wall-mural-b886' alt='Image 2'>";
        }

}
