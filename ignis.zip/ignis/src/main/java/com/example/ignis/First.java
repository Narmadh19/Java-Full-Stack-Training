package com.example.ignis;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class First {
    @GetMapping("/hi/{name}")

    public String hello(@PathVariable String name){
        return "Heyy Guys!!! I'm "+ name;
    }

}
