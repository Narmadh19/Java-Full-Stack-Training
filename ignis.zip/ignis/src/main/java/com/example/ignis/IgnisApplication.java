package com.example.ignis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IgnisApplication {

	public static void main(String[] args) {
		SpringApplication.run(IgnisApplication.class, args);
	}

}
